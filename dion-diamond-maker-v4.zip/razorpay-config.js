// ============================================================
// DION DIAMOND MAKER — Shared Razorpay Configuration
// ============================================================
// RAZORPAY_KEY_ID is the PUBLISHABLE "Key ID" (starts with rzp_test_
// or rzp_live_). It is safe to expose in client-side code — this is
// how every Razorpay Checkout.js integration works. It is NOT the
// same as your Key SECRET, which must never appear in any file that
// reaches the browser (Key Secret is only used server-side, e.g. in
// a Cloud Function, to verify payment signatures or call Razorpay's
// server APIs — this project does not currently have a backend, so
// no Key Secret should exist in any of these files).
//
// HOW TO GET YOUR KEY ID:
//   Razorpay Dashboard → Settings → API Keys → Generate Key
//   Use a "Test Mode" key while developing, switch to "Live Mode"
//   only once you're ready to accept real payments.
//
// Replace the placeholder below with your real Key ID before
// going live — until then, checkout will correctly show a
// "payment gateway not connected" message instead of a silent
// 401 error.
// ============================================================

const RAZORPAY_KEY_ID = "rzp_test_YOUR_KEY_HERE"; // <-- replace with your real Key ID

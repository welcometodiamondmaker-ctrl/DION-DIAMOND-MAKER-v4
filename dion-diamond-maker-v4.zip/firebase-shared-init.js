// ============================================================
// DION DIAMOND MAKER — SINGLE Firebase Initialization Point
// ============================================================
// Loaded by BOTH index.html and admin/index.html, right after the
// Firebase SDK <script> tags and firebase-config.js, and BEFORE any
// other app code. This is the ONLY place firebase.initializeApp() is
// ever called — every other file just reads firebase.firestore()/
// .auth()/.storage(), which are safe to call repeatedly.
(function () {
  if (typeof firebase === 'undefined') {
    console.error('Firebase SDK did not load (check your internet connection / ad-blocker / script order).');
    window.__firebaseReady = false;
    return;
  }
  if (typeof firebaseConfig === 'undefined' || firebaseConfig.apiKey === 'YOUR_API_KEY') {
    console.error('firebase-config.js is missing or still has placeholder values.');
    window.__firebaseReady = false;
    return;
  }
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }
  window.__firebaseReady = true;
})();

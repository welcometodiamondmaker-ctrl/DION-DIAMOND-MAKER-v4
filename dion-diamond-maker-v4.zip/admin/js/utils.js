// ============================================================
// DION DIAMOND MAKER ADMIN — Shared Utilities
// ============================================================
// Used by every module: toasts, confirm dialogs, escaping,
// formatting, pagination, drag-and-drop image upload to Storage.
// ============================================================

export function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function slugify(str) {
  return String(str || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export function formatCurrency(amount) {
  const n = Number(amount) || 0;
  return '₹' + n.toLocaleString('en-IN');
}

export function formatDate(timestamp) {
  if (!timestamp) return '—';
  const d = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) +
    ' · ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

export function debounce(fn, wait = 300) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

// Single source of truth for "low stock" — used by Inventory, Products list,
// and the Dashboard so all three always agree on the same number.
export const LOW_STOCK_THRESHOLD = 5;

// ---------------- TOASTS ----------------
let toastHost = null;
function ensureToastHost() {
  if (toastHost) return toastHost;
  toastHost = document.createElement('div');
  toastHost.className = 'toast-host';
  document.body.appendChild(toastHost);
  return toastHost;
}

export function toast(message, type = 'info') {
  const host = ensureToastHost();
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  host.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 250);
  }, 3200);
}

// ---------------- CONFIRM DIALOG ----------------
// Promise-based confirm modal — replaces window.confirm() with something
// that matches the admin's own design instead of a jarring browser popup.
export function confirmDialog(message, { title = 'Are you sure?', danger = true, confirmLabel = 'Confirm' } = {}) {
  return new Promise((resolve) => {
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.innerHTML = `
      <div class="modal-box modal-sm">
        <h3>${escapeHtml(title)}</h3>
        <p class="modal-msg">${escapeHtml(message)}</p>
        <div class="modal-actions">
          <button class="btn-secondary" data-action="cancel">Cancel</button>
          <button class="${danger ? 'btn-danger' : 'btn-primary'}" data-action="ok">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `;
    document.body.appendChild(bg);
    requestAnimationFrame(() => bg.classList.add('show'));
    function close(result) {
      bg.classList.remove('show');
      setTimeout(() => bg.remove(), 200);
      resolve(result);
    }
    bg.querySelector('[data-action="cancel"]').addEventListener('click', () => close(false));
    bg.querySelector('[data-action="ok"]').addEventListener('click', () => close(true));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(false); });
  });
}

// ---------------- LOADING BUTTON STATE ----------------
export function setButtonLoading(btn, isLoading, loadingText = 'Saving...') {
  if (!btn) return;
  if (isLoading) {
    btn.dataset.originalText = btn.dataset.originalText || btn.textContent;
    btn.textContent = loadingText;
    btn.disabled = true;
    btn.classList.add('is-loading');
  } else {
    btn.textContent = btn.dataset.originalText || btn.textContent;
    btn.disabled = false;
    btn.classList.remove('is-loading');
  }
}

// ---------------- PAGINATION ----------------
// Pure helper: given a full array + page size + current page, returns the
// page's slice plus metadata for rendering page-number controls.
export function paginate(items, page, pageSize) {
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const start = (safePage - 1) * pageSize;
  return {
    pageItems: items.slice(start, start + pageSize),
    page: safePage,
    totalPages,
    totalItems: items.length
  };
}

export function renderPaginationControls(containerId, page, totalPages, onPageChange) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (totalPages <= 1) { el.innerHTML = ''; return; }
  let html = `<button class="page-btn" ${page === 1 ? 'disabled' : ''} data-page="${page - 1}">‹ Prev</button>`;
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
      html += `<button class="page-btn ${p === page ? 'active' : ''}" data-page="${p}">${p}</button>`;
    } else if (Math.abs(p - page) === 2) {
      html += `<span class="page-ellipsis">…</span>`;
    }
  }
  html += `<button class="page-btn" ${page === totalPages ? 'disabled' : ''} data-page="${page + 1}">Next ›</button>`;
  el.innerHTML = html;
  el.querySelectorAll('.page-btn[data-page]').forEach(btn => {
    btn.addEventListener('click', () => onPageChange(Number(btn.dataset.page)));
  });
}

// ---------------- IMAGE COMPRESSION ----------------
// Resizes/compresses an image client-side before upload — keeps Storage
// usage and page-load weight down without needing a server.
export function compressImage(file, maxWidth = 1600, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) { reject(new Error('Not an image file')); return; }
    const img = new Image();
    const reader = new FileReader();
    reader.onload = (e) => { img.src = e.target.result; };
    reader.onerror = reject;
    img.onload = () => {
      const scale = Math.min(1, maxWidth / img.width);
      const canvas = document.createElement('canvas');
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        if (!blob) { reject(new Error('Compression failed')); return; }
        resolve(blob);
      }, 'image/webp', quality);
    };
    img.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ---------------- DRAG-AND-DROP IMAGE UPLOADER ----------------
// Wires up a drop-zone element + hidden file input for multi-image upload
// with preview, replace, delete, and a primary-image toggle. Calls
// onChange(images) every time the list changes, where images is an array
// of { url, path, isPrimary, _uploading? }.
//
// IMPORTANT — deferred deletion: removing/replacing an EXISTING (already-saved)
// image does NOT delete it from Storage immediately. It's only queued for
// deletion. The parent form must call commit() after a successful Firestore
// save (actually deletes the old files) or rollback() if the user cancels
// (deletes only this session's brand-new uploads, leaves saved images alone).
// This prevents a cancelled edit from leaving the live product pointing at a
// Storage file that's already been deleted (a broken image on the storefront).
export function initImageUploader({ dropZoneEl, fileInputEl, previewListEl, storage, storagePathPrefix, initialImages = [], onChange }) {
  let images = initialImages.map(im => ({ ...im }));
  const initialPaths = new Set(initialImages.map(im => im.path).filter(Boolean));
  let pendingDeletePaths = []; // existing/saved images queued for deletion — only deleted on commit()

  function emit() { onChange([...images]); }

  // An existing (already-saved) image gets queued for later deletion.
  // A brand-new upload from this session that's being undone (removed/replaced
  // before ever being saved) is safe to delete from Storage right away — nothing
  // refers to it yet.
  function disposeOfPath(path) {
    if (!path) return;
    if (initialPaths.has(path)) {
      pendingDeletePaths.push(path);
    } else {
      storage.ref(path).delete().catch((e) => console.warn('Cleanup of unsaved upload failed:', e));
    }
  }

  function renderPreviews() {
    previewListEl.innerHTML = images.map((img, i) => `
      <div class="img-thumb ${img.isPrimary ? 'is-primary' : ''}" data-index="${i}">
        ${img._uploading
          ? `<div class="img-thumb-loading"><div class="spinner"></div></div>`
          : `<img src="${img.url}" alt="">`
        }
        <div class="img-thumb-actions">
          <button type="button" class="thumb-btn" data-act="moveleft" title="Move left" ${i === 0 ? 'disabled' : ''}>‹</button>
          <button type="button" class="thumb-btn" data-act="primary" title="Set as primary">${img.isPrimary ? '★' : '☆'}</button>
          <button type="button" class="thumb-btn" data-act="replace" title="Replace">⟲</button>
          <button type="button" class="thumb-btn thumb-btn-danger" data-act="remove" title="Remove">✕</button>
          <button type="button" class="thumb-btn" data-act="moveright" title="Move right" ${i === images.length - 1 ? 'disabled' : ''}>›</button>
        </div>
      </div>
    `).join('') + `<div class="img-thumb img-thumb-add" data-act="add"><span>+ Add</span></div>`;

    previewListEl.querySelectorAll('.img-thumb[data-index]').forEach(thumbEl => {
      const idx = Number(thumbEl.dataset.index);
      thumbEl.querySelector('[data-act="moveleft"]')?.addEventListener('click', () => {
        if (idx === 0) return;
        [images[idx - 1], images[idx]] = [images[idx], images[idx - 1]];
        renderPreviews(); emit();
      });
      thumbEl.querySelector('[data-act="moveright"]')?.addEventListener('click', () => {
        if (idx === images.length - 1) return;
        [images[idx + 1], images[idx]] = [images[idx], images[idx + 1]];
        renderPreviews(); emit();
      });
      thumbEl.querySelector('[data-act="primary"]')?.addEventListener('click', () => {
        images.forEach((im, i) => im.isPrimary = (i === idx));
        renderPreviews(); emit();
      });
      thumbEl.querySelector('[data-act="remove"]')?.addEventListener('click', () => {
        const removed = images[idx];
        images.splice(idx, 1);
        if (images.length && !images.some(im => im.isPrimary)) images[0].isPrimary = true;
        renderPreviews(); emit();
        disposeOfPath(removed?.path);
      });
      thumbEl.querySelector('[data-act="replace"]')?.addEventListener('click', () => {
        fileInputEl.dataset.replaceIndex = idx;
        fileInputEl.click();
      });
    });
    previewListEl.querySelector('[data-act="add"]')?.addEventListener('click', () => {
      delete fileInputEl.dataset.replaceIndex;
      fileInputEl.click();
    });
  }

  async function handleFiles(fileList) {
    const files = Array.from(fileList).filter(f => f.type.startsWith('image/'));
    if (!files.length) { toast('Please choose image files only.', 'error'); return; }
    const replaceIndex = fileInputEl.dataset.replaceIndex !== undefined ? Number(fileInputEl.dataset.replaceIndex) : null;

    for (const file of files) {
      if (file.size > 8 * 1024 * 1024) { toast(`"${file.name}" is too large (max 8MB).`, 'error'); continue; }
      // Capture the path being replaced NOW, before it's overwritten by the
      // loading placeholder below — reading it later (e.g. from the original
      // initialImages array by index) breaks once the array has been
      // reordered/edited, which silently deleted the wrong file before.
      const replacedPath = replaceIndex !== null ? images[replaceIndex]?.path : null;
      const placeholder = { url: '', path: '', isPrimary: images.length === 0 && replaceIndex === null, _uploading: true };
      let targetIndex;
      if (replaceIndex !== null) {
        const old = images[replaceIndex];
        placeholder.isPrimary = old.isPrimary;
        images[targetIndex = replaceIndex] = placeholder;
      } else {
        targetIndex = images.length;
        images.push(placeholder);
      }
      renderPreviews();

      try {
        const blob = await compressImage(file);
        const path = `${storagePathPrefix}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.webp`;
        const ref = storage.ref(path);
        await ref.put(blob);
        const url = await ref.getDownloadURL();
        images[targetIndex] = { url, path, isPrimary: placeholder.isPrimary };
        renderPreviews(); emit();
        if (replacedPath && replacedPath !== path) disposeOfPath(replacedPath);
      } catch (e) {
        console.error('Image upload failed:', e);
        toast('Image upload failed: ' + e.message, 'error');
        images.splice(targetIndex, 1);
        renderPreviews(); emit();
      }
    }
    delete fileInputEl.dataset.replaceIndex;
  }

  fileInputEl.addEventListener('change', (e) => { handleFiles(e.target.files); e.target.value = ''; });
  dropZoneEl.addEventListener('dragover', (e) => { e.preventDefault(); dropZoneEl.classList.add('drag-over'); });
  dropZoneEl.addEventListener('dragleave', () => dropZoneEl.classList.remove('drag-over'));
  dropZoneEl.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZoneEl.classList.remove('drag-over');
    handleFiles(e.dataTransfer.files);
  });
  dropZoneEl.addEventListener('click', () => { delete fileInputEl.dataset.replaceIndex; fileInputEl.click(); });

  renderPreviews();
  return {
    getImages: () => [...images],
    // Call after a successful Firestore save: actually deletes any
    // replaced/removed EXISTING images from Storage.
    commit: async () => {
      await Promise.all(pendingDeletePaths.map(p => storage.ref(p).delete().catch((e) => console.warn('Deferred delete failed:', e))));
      pendingDeletePaths = [];
    },
    // Call when the form is cancelled/closed without saving: deletes only
    // this session's brand-new uploads still sitting in `images` (never
    // referenced by any saved document), leaves originally-saved images
    // and their Storage files completely untouched.
    rollback: async () => {
      const newOnes = images.filter(im => im.path && !initialPaths.has(im.path));
      await Promise.all(newOnes.map(im => storage.ref(im.path).delete().catch(() => {})));
      pendingDeletePaths = [];
    }
  };
}

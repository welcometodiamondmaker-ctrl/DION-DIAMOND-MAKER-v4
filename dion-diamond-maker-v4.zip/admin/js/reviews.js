// ============================================================
// DION DIAMOND MAKER ADMIN — Video Reviews Moderation
// ============================================================
import { db, storage, fbReady } from './firebase-init.js';
import { escapeHtml, toast, confirmDialog } from './utils.js';

let reviews = [];

export function init(container) {
  container.innerHTML = `
    <p class="toolbar-hint">Approve, reject, or remove video reviews. Only <strong>approved</strong> reviews appear in the public gallery on the website.</p>
    <div class="vid-grid" id="reviewsGrid"><div class="empty-state">Loading reviews...</div></div>
  `;
  if (!fbReady) { document.getElementById('reviewsGrid').innerHTML = `<div class="empty-state">Firebase isn't connected.</div>`; return; }

  db.collection('videoReviews').orderBy('createdAt', 'desc').onSnapshot((snap) => {
    reviews = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    render();
    window.dispatchEvent(new CustomEvent('admin:reviews-updated', { detail: { reviews } }));
  }, (e) => {
    console.error('Reviews load error:', e);
    document.getElementById('reviewsGrid').innerHTML = `<div class="empty-state">Failed to load reviews: ${escapeHtml(e.message)}</div>`;
  });
}

export function getReviews() { return reviews; }

function statusBadge(status) {
  const s = status || 'pending';
  if (s === 'approved') return '<span class="badge badge-delivered">Approved</span>';
  if (s === 'rejected') return '<span class="badge badge-cancelled">Rejected</span>';
  return '<span class="badge badge-pending">Pending review</span>';
}

function render() {
  const grid = document.getElementById('reviewsGrid');
  if (!grid) return;
  if (reviews.length === 0) { grid.innerHTML = '<div class="empty-state">No video reviews yet.</div>'; return; }
  grid.innerHTML = reviews.map(r => {
    const status = r.status || 'pending';
    const actionButtons = status === 'pending'
      ? `<button class="icon-btn ship" data-act="approve" data-id="${r.id}" style="width:100%; margin-bottom:6px;">Approve</button>
         <button class="icon-btn danger" data-act="reject" data-id="${r.id}" style="width:100%; margin-bottom:6px;">Reject</button>`
      : `<button class="icon-btn" data-act="pending" data-id="${r.id}" style="width:100%; margin-bottom:6px;">Move to Pending</button>`;
    return `
      <div class="vid-card">
        <video src="${r.videoUrl}" controls muted preload="metadata"></video>
        <div class="vid-meta">
          <div class="vname">${escapeHtml(r.name || '—')}</div>
          <div class="vmeta-sub">${escapeHtml(r.product || '')} · ${r.likes || 0} likes</div>
          <div style="margin:6px 0 10px;">${statusBadge(status)}</div>
          ${actionButtons}
          <button class="icon-btn danger" data-act="delete" data-id="${r.id}" data-path="${escapeHtml(r.storagePath || '')}" style="width:100%;">Delete</button>
        </div>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('[data-act="approve"]').forEach(b => b.addEventListener('click', () => setStatus(b.dataset.id, 'approved')));
  grid.querySelectorAll('[data-act="reject"]').forEach(b => b.addEventListener('click', () => setStatus(b.dataset.id, 'rejected')));
  grid.querySelectorAll('[data-act="pending"]').forEach(b => b.addEventListener('click', () => setStatus(b.dataset.id, 'pending')));
  grid.querySelectorAll('[data-act="delete"]').forEach(b => b.addEventListener('click', () => deleteReview(b.dataset.id, b.dataset.path)));
}

async function setStatus(id, status) {
  try {
    await db.collection('videoReviews').doc(id).update({ status });
    toast(`Review marked as ${status}`, 'success');
  } catch (e) { toast('Update failed: ' + e.message, 'error'); }
}

async function deleteReview(id, storagePath) {
  const ok = await confirmDialog('Delete this video review? This cannot be undone.', { title: 'Delete review', confirmLabel: 'Delete' });
  if (!ok) return;
  try {
    await db.collection('videoReviews').doc(id).delete();
    if (storagePath) { try { await storage.ref(storagePath).delete(); } catch (e) { console.warn('Storage delete failed:', e); } }
    toast('Review deleted', 'success');
  } catch (e) { toast('Delete failed: ' + e.message, 'error'); }
}

// ============================================================
// DION DIAMOND MAKER ADMIN — Dashboard
// ============================================================
import { escapeHtml, formatCurrency, LOW_STOCK_THRESHOLD } from './utils.js';
import { getOrders } from './orders.js';
import { getProducts } from './products.js';
import { getReviews } from './reviews.js';

export function init(container) {
  container.innerHTML = `
    <div class="stat-row" id="dashStatRow"></div>
    <h3 class="serif section-label">Revenue by Product</h3>
    <div class="chart-block" id="dashRevenueByProduct"></div>
    <h3 class="serif section-label">Orders — Last 7 Days</h3>
    <div class="chart-block" id="dashOrdersLast7Days"></div>
    <h3 class="serif section-label">Recent Orders</h3>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Customer</th><th>Product</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody id="dashRecentOrders"></tbody>
      </table>
    </div>
  `;
  window.addEventListener('admin:orders-updated', render);
  window.addEventListener('admin:products-updated', render);
  window.addEventListener('admin:reviews-updated', render);
  render();
}

function barRow(label, value, max, valueText) {
  const pct = max > 0 ? Math.max((value / max) * 100, value > 0 ? 2 : 0) : 0;
  return `
    <div class="bar-row">
      <div class="bar-label">${escapeHtml(label)}</div>
      <div class="bar-track"><div class="bar-fill gold" style="width:${pct}%"></div></div>
      <div class="bar-value">${escapeHtml(valueText)}</div>
    </div>
  `;
}

function render() {
  const statRow = document.getElementById('dashStatRow');
  if (!statRow) return;
  const orders = getOrders();
  const products = getProducts();
  const reviews = getReviews();

  const paidOrders = orders.filter(o => o.status !== 'Payment Failed' && o.status !== 'Cancelled');
  const totalRevenue = paidOrders.reduce((s, o) => s + (Number(o.amount) || 0), 0);
  const pendingOrders = orders.filter(o => o.status === 'Pending').length;
  const lowStockCount = products.filter(p => {
    const stock = p.variants?.length ? p.variants.reduce((s, v) => s + (Number(v.stock) || 0), 0) : (Number(p.stock) || 0);
    return stock <= LOW_STOCK_THRESHOLD;
  }).length;
  const pendingReviews = reviews.filter(r => (r.status || 'pending') === 'pending').length;

  statRow.innerHTML = `
    <div class="stat-card"><div class="num">${formatCurrency(totalRevenue)}</div><div class="lbl">Total Revenue</div></div>
    <div class="stat-card"><div class="num">${orders.length}</div><div class="lbl">Total Orders</div></div>
    <div class="stat-card"><div class="num">${pendingOrders}</div><div class="lbl">Pending Orders</div></div>
    <div class="stat-card"><div class="num">${products.length}</div><div class="lbl">Products</div></div>
    <div class="stat-card"><div class="num ${lowStockCount > 0 ? 'stock-low' : ''}">${lowStockCount}</div><div class="lbl">Low Stock Items</div></div>
    <div class="stat-card"><div class="num ${pendingReviews > 0 ? 'stock-low' : ''}">${pendingReviews}</div><div class="lbl">Reviews Awaiting Approval</div></div>
  `;

  // Revenue by product
  const revenueByProduct = {};
  paidOrders.forEach(o => { const k = o.product || 'Other'; revenueByProduct[k] = (revenueByProduct[k] || 0) + (Number(o.amount) || 0); });
  const revEntries = Object.entries(revenueByProduct).sort((a, b) => b[1] - a[1]);
  const revBox = document.getElementById('dashRevenueByProduct');
  revBox.innerHTML = revEntries.length === 0
    ? '<div class="empty-state">No revenue yet.</div>'
    : (() => { const max = Math.max(...revEntries.map(e => e[1])); return revEntries.map(([n, a]) => barRow(n, a, max, formatCurrency(a))).join(''); })();

  // Last 7 days
  const days = [];
  const today = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today); d.setDate(d.getDate() - i);
    days.push({ key: d.toDateString(), label: d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' }), count: 0 });
  }
  orders.forEach(o => {
    if (!o.createdAt?.toDate) return;
    const d = o.createdAt.toDate().toDateString();
    const day = days.find(x => x.key === d);
    if (day) day.count += 1;
  });
  const maxDay = Math.max(1, ...days.map(d => d.count));
  document.getElementById('dashOrdersLast7Days').innerHTML = days.map(d => barRow(d.label, d.count, maxDay, String(d.count))).join('');

  // Recent orders
  const recentTbody = document.getElementById('dashRecentOrders');
  const recent = orders.slice(0, 6);
  recentTbody.innerHTML = recent.length === 0
    ? '<tr><td colspan="4" class="empty-state">No orders yet.</td></tr>'
    : recent.map(o => `
      <tr>
        <td>${escapeHtml(o.name)}</td>
        <td>${escapeHtml(o.product || '—')}</td>
        <td>${formatCurrency(o.amount)}</td>
        <td><span class="badge ${o.status === 'Delivered' ? 'badge-delivered' : o.status === 'Shipped' ? 'badge-shipped' : (o.status === 'Cancelled' || o.status === 'Payment Failed') ? 'badge-cancelled' : 'badge-pending'}">${escapeHtml(o.status || 'Pending')}</span></td>
      </tr>
    `).join('');
}

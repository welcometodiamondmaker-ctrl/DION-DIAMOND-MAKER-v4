// ============================================================
// DION DIAMOND MAKER ADMIN — App Shell
// ============================================================
import { auth, fbReady } from './firebase-init.js';
import { toast } from './utils.js';
import * as Dashboard from './dashboard.js';
import * as Products from './products.js';
import * as Orders from './orders.js';
import * as Customers from './customers.js';
import * as Inventory from './inventory.js';
import * as Coupons from './coupons.js';
import * as Reviews from './reviews.js';

// Phase 1 = built now. Phase 2 = on the roadmap, shown disabled so the
// full intended structure is visible (Shopify/WooCommerce-style sidebar).
const NAV_SECTIONS = [
  { group: 'Overview', items: [
    { tab: 'dashboard', label: 'Dashboard', module: Dashboard, phase: 1 }
  ]},
  { group: 'Catalog', items: [
    { tab: 'products', label: 'Products', module: Products, phase: 1 },
    { tab: 'inventory', label: 'Inventory', module: Inventory, phase: 1 },
    { tab: 'coupons', label: 'Coupons', module: Coupons, phase: 1 },
    { tab: 'media', label: 'Media Library', phase: 2 }
  ]},
  { group: 'Sales', items: [
    { tab: 'orders', label: 'Orders', module: Orders, phase: 1 },
    { tab: 'customers', label: 'Customers', module: Customers, phase: 1 }
  ]},
  { group: 'Content', items: [
    { tab: 'reviews', label: 'Video Reviews', module: Reviews, phase: 1 },
    { tab: 'homepage', label: 'Homepage Builder', phase: 2 },
    { tab: 'blog', label: 'Blog', phase: 2 }
  ]},
  { group: 'Insights', items: [
    { tab: 'reports', label: 'Reports', phase: 2 }
  ]},
  { group: 'Settings', items: [
    { tab: 'payments', label: 'Payment Settings', phase: 2 },
    { tab: 'shipping', label: 'Shipping Settings', phase: 2 },
    { tab: 'roles', label: 'User Roles', phase: 2 },
    { tab: 'website', label: 'Website Settings', phase: 2 },
    { tab: 'security', label: 'Security', phase: 2 }
  ]}
];

let initialized = false;

function renderSidebar() {
  const nav = document.getElementById('sidebarNav');
  nav.innerHTML = NAV_SECTIONS.map(section => `
    <div class="nav-group-label">${section.group}</div>
    ${section.items.map(item => item.phase === 2
      ? `<button class="nav-btn disabled" disabled title="Coming in Phase 2">${item.label} <span class="soon">Soon</span></button>`
      : `<button class="nav-btn" data-tab="${item.tab}">${item.label}</button>`
    ).join('')}
  `).join('');

  nav.querySelectorAll('.nav-btn[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });
}

function renderPanelShells() {
  const content = document.getElementById('mainContent');
  const allItems = NAV_SECTIONS.flatMap(s => s.items).filter(i => i.phase === 1);
  content.innerHTML = allItems.map(item => `<div class="panel" id="panel-${item.tab}"></div>`).join('');
}

function switchTab(tab) {
  document.querySelectorAll('.nav-btn[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + tab)?.classList.add('active');
  document.getElementById('topbarTitle').textContent = NAV_SECTIONS.flatMap(s => s.items).find(i => i.tab === tab)?.label || '';
  document.getElementById('sidebar').classList.remove('open'); // close mobile menu after navigating
}

function initModules() {
  if (initialized) return;
  initialized = true;
  renderPanelShells();
  // Order matters a little: modules that others read from via getX() should
  // start their Firestore listeners first so data is available ASAP.
  Products.init(document.getElementById('panel-products'));
  Orders.init(document.getElementById('panel-orders'));
  Reviews.init(document.getElementById('panel-reviews'));
  Customers.init(document.getElementById('panel-customers'));
  Inventory.init(document.getElementById('panel-inventory'));
  Coupons.init(document.getElementById('panel-coupons'));
  Dashboard.init(document.getElementById('panel-dashboard'));
  switchTab('dashboard');
}

function showShell() {
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('adminShell').classList.add('show');
  initModules();
}
function showLogin() {
  document.getElementById('loginScreen').style.display = 'flex';
  document.getElementById('adminShell').classList.remove('show');
}

// ---------------- AUTH ----------------
function setupAuth() {
  if (!fbReady) {
    document.getElementById('loginErr').textContent = 'Firebase is not connected — check firebase-config.js in the project root.';
    document.getElementById('loginErr').classList.add('show');
    return;
  }
  auth.onAuthStateChanged(user => { user ? showShell() : showLogin(); });

  document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errEl = document.getElementById('loginErr');
    const btn = document.getElementById('loginBtn');
    errEl.classList.remove('show');
    btn.disabled = true; btn.textContent = 'Signing in...';
    auth.signInWithEmailAndPassword(email, password)
      .catch(err => {
        errEl.textContent = err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found'
          ? 'Incorrect email or password.' : err.message;
        errEl.classList.add('show');
      })
      .finally(() => { btn.disabled = false; btn.textContent = 'Sign In'; });
  });

  document.getElementById('logoutBtn').addEventListener('click', () => auth.signOut());

  document.getElementById('forgotLink').addEventListener('click', async () => {
    const email = document.getElementById('loginEmail').value.trim();
    const errEl = document.getElementById('loginErr');
    const okEl = document.getElementById('loginOk');
    errEl.classList.remove('show'); okEl.classList.remove('show');
    if (!email) { errEl.textContent = 'Enter your email above first, then click "Forgot password?"'; errEl.classList.add('show'); return; }
    try {
      await auth.sendPasswordResetEmail(email);
      okEl.textContent = `Password reset link sent to ${email} — check your inbox.`;
      okEl.classList.add('show');
    } catch (e) {
      errEl.textContent = e.code === 'auth/user-not-found' ? 'No admin account found with that email.' : e.message;
      errEl.classList.add('show');
    }
  });
}

document.getElementById('menuToggle').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));

renderSidebar();
setupAuth();

// ============================================================
// DION DIAMOND MAKER ADMIN — Firebase Initialization
// ============================================================
// Relies on `firebase` (compat SDK) and `firebaseConfig` already being
// defined as globals — loaded via classic <script> tags in index.html
// BEFORE this module. firebaseConfig itself lives in ../firebase-config.js
// (one directory up — same file the public website uses).
// ============================================================

// ============================================================
// DION DIAMOND MAKER ADMIN — Firebase Instance Access
// ============================================================
// The ACTUAL firebase.initializeApp() call happens in exactly one place:
// ../../firebase-shared-init.js (loaded as a classic <script>, before this
// module, in admin/index.html). This file just reads the already-initialized
// instances — it never calls initializeApp() itself.

export let auth, db, storage;
export let fbReady = false;

try {
  if (!window.__firebaseReady) {
    throw new Error('Firebase did not initialize — see the earlier console error from firebase-shared-init.js.');
  }
  auth = firebase.auth();
  db = firebase.firestore();
  storage = firebase.storage();
  fbReady = true;
} catch (e) {
  console.error('Firebase access failed:', e);
  fbReady = false;
}

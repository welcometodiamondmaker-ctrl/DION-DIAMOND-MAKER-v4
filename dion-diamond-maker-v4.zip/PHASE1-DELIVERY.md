# Dion Diamond Maker — Admin Panel Rebuild · Phase 1 Delivery

Built from scratch, vanilla JS (no React), Firebase Firestore + Storage + Auth, no build step (native ES modules). Public website design/branding untouched — only specific elements were wired to sync live with the new admin.

---

## 1. Complete Folder Structure

```
diamond-maker-website/
├── index.html                  (MODIFIED — public website)
├── admin.html                  (MODIFIED — now a redirect to /admin/)
├── firebase-config.js          (unchanged — shared Firebase config)
├── razorpay-config.js          (unchanged — shared Razorpay key)
├── firebase.json               (unchanged — hosting/rules deploy config)
├── firestore.rules             (MODIFIED — new collections added)
├── firestore.indexes.json      (unchanged)
├── storage.rules               (MODIFIED — product images path added)
├── robots.txt                  (MODIFIED — disallows /admin/)
├── sitemap.xml                 (unchanged)
├── images/                     (unchanged — 8 product/brand images)
│
├── admin/                      ★ NEW — the rebuilt admin panel
│   ├── index.html              ★ NEW — shell: login + sidebar layout
│   ├── css/
│   │   └── admin.css           ★ NEW — full stylesheet (~280 lines)
│   └── js/
│       ├── firebase-init.js    ★ NEW — Firebase bootstrap
│       ├── utils.js            ★ NEW — toasts, confirm dialogs, image upload, pagination
│       ├── app.js              ★ NEW — sidebar nav, auth gate, tab routing
│       ├── dashboard.js        ★ NEW — stats, charts, recent orders
│       ├── products.js         ★ NEW — full product CRUD
│       ├── orders.js           ★ NEW — order management
│       ├── customers.js        ★ NEW — customer view + notes
│       ├── inventory.js        ★ NEW — stock management
│       ├── coupons.js          ★ NEW — coupon CRUD
│       └── reviews.js          ★ NEW — video review moderation
│
└── _archive/                   (not part of the live site — kept for reference)
    ├── admin-old-single-file-backup.html      (your previous admin.html)
    └── index_standalone-unused-legacy-export.html  (unused 6.4MB export — safe to delete)
```

**~1,660 lines of new JS** across the 10 admin modules, plus ~280 lines of CSS and the HTML shell.

---

## 2. Every Modified File

| File | What changed |
|---|---|
| `index.html` | Added `id`s to the 3 price/buy-button elements (`priceGlowe`/`buyBtnGlowe`, etc.) and a new `syncProductsFromFirestore()` function — listens to Firestore `products` (by `slug`) and live-updates price, stock/out-of-stock state, and the Buy button's behavior whenever an admin publishes a change. **Falls back to the original hardcoded price/copy** if Firestore has no matching *active* product yet, so nothing can break. |
| `admin.html` | Replaced the old single-file admin (now archived) with a 12-line redirect to `/admin/`, so old bookmarks/links still work. |
| `firestore.rules` | Added rules for `categories`, `coupons`, `customerNotes` (new collections this phase introduced). |
| `storage.rules` | Added a rule for the `products/{productId}/{fileId}` path (product gallery images), admin-write / public-read, 8MB + image-type enforced server-side. |
| `robots.txt` | Added `Disallow: /admin/` alongside the existing `/admin.html` entry. |

---

## 3. Every Newly Created File

**`admin/index.html`** — Login screen (same branding as before) + sidebar shell. Loads Firebase SDK classic scripts first, then `js/app.js` as an ES module.

**`admin/css/admin.css`** — Sidebar nav, topbar, stat cards, CSS-only bar charts, data tables, badges, pagination, modals, forms, drag-and-drop image uploader, tag-input chips, toasts, video review grid, mobile responsive breakpoints. Same brand tokens (gold `#C9A24B` / cream / forest / aubergine) as the rest of the site.

**`admin/js/firebase-init.js`** — Initializes Firebase once, exports `auth`/`db`/`storage`/`fbReady` for every other module to import. Guards against the placeholder-config and "already initialized" errors.

**`admin/js/utils.js`** — Shared toolkit used by every module:
- `escapeHtml`, `slugify`, `formatCurrency`, `formatDate`, `debounce`
- `toast()` — non-blocking success/error notifications
- `confirmDialog()` — promise-based confirm modal (replaces `window.confirm`)
- `setButtonLoading()` — consistent loading-state on buttons
- `paginate()` / `renderPaginationControls()` — reusable pagination
- `compressImage()` — client-side resize to WebP before upload (keeps Storage costs/page-weight down)
- `initImageUploader()` — full drag-and-drop multi-image uploader: preview, replace, delete, set-primary, all wired to Firebase Storage

**`admin/js/products.js`** — Product Management:
- List: search (name/SKU), category filter, status filter, pagination
- Add/Edit form: multi-image gallery (drag-drop), SKU (uniqueness-checked), category (with inline "+ New" creation), price + compare-at price, stock, **variants** (e.g. different pack sizes, each with its own SKU/price/stock), ingredients & benefits (tag-input), short + full description, SEO title/description/slug, status (Draft/Active), featured toggle
- Duplicate product, delete product (cleans up its Storage images too)
- Publishes `admin:products-updated` event so Dashboard/Inventory stay in sync

**`admin/js/orders.js`** — Order Management: search (name/phone/order ID), status filter, pagination, detail modal (full address, payment ID, failure reason if any), status update with confirmation.

**`admin/js/customers.js`** — Customer Management: **derived live from real orders** (grouped by phone) so it can never drift out of sync — no separate denormalized customer collection to maintain. Search, order history per customer, and an admin-only tag/note (stored in a small `customerNotes` collection).

**`admin/js/inventory.js`** — Flattens every product (and every variant) into one stock list, with low-stock/out-of-stock highlighting and one-click quick stock updates — no need to open the full product form just to adjust a number.

**`admin/js/coupons.js`** — Full CRUD for discount codes: percentage or flat amount, minimum order value, max uses, expiry date, active toggle. Coupon code is the document ID itself, so the storefront can validate a code with a single direct lookup later (rules already support this — see below).

**`admin/js/reviews.js`** — Approve / Reject / Delete video reviews (ported and cleaned up from the previous round). Only **approved** reviews show in the public gallery.

**`admin/js/dashboard.js`** — Revenue, order counts, low-stock count, reviews-awaiting-approval count, revenue-by-product and last-7-days order trend (CSS bar charts, no chart library needed), recent orders table.

**`admin/js/app.js`** — Sidebar navigation (grouped: Overview / Catalog / Sales / Content / Insights / Settings), with **Phase 2 items visibly listed but disabled** ("Soon" badge) so the intended full structure is visible. Auth gate (sign in / sign out), mobile hamburger toggle, wires all 7 Phase-1 modules together.

---

## 4. Firestore Rules (`firestore.rules`)

Full file is in the project root. Summary of what's enforced:

| Collection | Public can... | Admin (signed in) can... |
|---|---|---|
| `orders` | Create a new order (validated: required fields, phone/pincode format, amount range, status locked to Pending/Payment Failed); retry the *same* checkout attempt (failed→success) without changing price/customer details | Read, update (any status), delete |
| `products` | Read only | Full write |
| `categories` | Read only | Full write |
| `coupons` | Get a single coupon by exact code (can't list/enumerate all codes); bump `usedCount` by exactly +1 | Full CRUD |
| `customerNotes` | No access | Full read/write |
| `videoReviews` | Create (forced to `status:'pending'`); read only `approved` ones; toggle `likes` ±1 on an approved review | Full read/write (moderation) |
| everything else | Denied | Denied |

## 5. Storage Rules (`storage.rules`)

| Path | Public can... | Admin can... |
|---|---|---|
| `products/{productId}/{fileId}` | Read | Write (8MB limit, must be an image) |
| `video-reviews/{fileId}` | Read; Create (5MB limit, must be a video) | Delete |
| everything else | Denied | Denied |

## 6. Firestore Indexes (`firestore.indexes.json`)

One composite index (carried over from the previous round, still required):
`videoReviews`: `status` (ASC) + `likes` (DESC) — needed for the public gallery's "approved, sorted by likes" query.

No *new* composite indexes were needed for Phase 1 — all new admin queries either have no `where` clause or filter client-side after a simple `orderBy`.

---

## 7. Deployment Guide

**A. One-time Firebase CLI setup** (skip if already done):
```bash
npm install -g firebase-tools
firebase login
firebase use diamond-maker-7be3e
```

**B. Deploy security rules + indexes** (do this BEFORE deploying the site, so the new admin isn't blocked):
```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
```

**C. Create your admin login** (one-time, if you haven't already):
Firebase Console → Authentication → Users → Add User → enter your email + a password. That's the login for `/admin/`.

**D. Deploy the website + admin panel:**
```bash
firebase deploy --only hosting
```
(Or upload the whole folder via your existing hosting provider — every file is static, no server/build step required.)

**E. Add your real keys before going live:**
- `razorpay-config.js` → replace `rzp_test_YOUR_KEY_HERE` with your real Razorpay Key ID.
- `firebase-config.js` → already filled in with your project's config from before.

**F. Seed your products (important):**
The 3 product cards on the homepage still work with their original hardcoded prices **until** you create matching products in the new admin panel. To connect them:
1. Go to `/admin/` → Products → Add Product
2. Use these exact **slugs** so the homepage knows which card to update: `glowe-face-serum`, `oriva7-capsule`, `health-wellness-kit`
3. Set Status to **Active** — Draft products never override the live homepage.
4. Price/stock changes you make from then on appear on the homepage within seconds, no redeploy needed.

---

## 8. Testing Checklist

**Admin login & navigation**
- [ ] `/admin/` redirects to login when signed out
- [ ] Old `/admin.html` redirects to `/admin/`
- [ ] Wrong password shows "Incorrect email or password"
- [ ] Sidebar shows all 7 Phase-1 items active + 8 Phase-2 items visibly disabled
- [ ] Mobile width (<980px): hamburger icon opens/closes sidebar

**Products**
- [ ] Add a product with 2+ images via drag-and-drop — both upload, preview correctly
- [ ] Click ☆ on a non-primary image → becomes ★ primary
- [ ] Replace one image — old file is deleted from Storage, new one appears
- [ ] Add a variant, save — stock field above auto-disables ("managed per variant")
- [ ] Try saving with a duplicate SKU — blocked with a clear error
- [ ] Add ingredients/benefits via tag input (Enter to add, ✕ to remove, Backspace on empty to pop last)
- [ ] Set status to Active with slug `glowe-face-serum` → homepage price updates within a few seconds
- [ ] Set the same product to Draft → homepage reverts to original hardcoded price
- [ ] Set stock to 0 on a tracked product → homepage Buy button shows "Out of Stock" and is disabled
- [ ] Duplicate a product → appears as Draft with "(Copy)" suffix
- [ ] Delete a product → confirmation dialog appears, images removed from Storage after confirming

**Orders**
- [ ] Place a real test order on the homepage → appears in admin Orders within seconds (live, no refresh)
- [ ] Search by phone number filters correctly
- [ ] Status filter dropdown works
- [ ] Open order detail, change status to Shipped → badge updates immediately

**Customers**
- [ ] Customer from the test order above appears, with correct order count/total spent
- [ ] Add a tag + note, save, reopen — persisted

**Inventory**
- [ ] Shows one row per variant (if any) or one row per product
- [ ] Low-stock toggle filters to ≤5 stock items only
- [ ] Quick-update a stock number → Products tab and homepage both reflect it

**Coupons**
- [ ] Create a percent coupon and a flat coupon
- [ ] Try creating a duplicate code → blocked
- [ ] Try a percent value over 100 → blocked

**Video Reviews**
- [ ] Submit a review on the homepage → shows as "Pending review" in admin, does NOT yet appear in the public gallery
- [ ] Approve it → appears in the public gallery within seconds
- [ ] Reject it → stays hidden, status badge updates
- [ ] Delete → removed from Firestore and Storage

**Console**
- [ ] Open DevTools console on both the homepage and `/admin/` → zero red errors during normal use

---

## 9. Remaining Phase 2 Items

These are visible (disabled) in the new sidebar but not yet built — say the word and I'll start the next one:

1. **Media Library** — browse/manage all uploaded Storage files in one place (not just per-product)
2. **Homepage Builder** — drag-and-drop control over hero/sections without editing HTML
3. **Blog** — post CRUD + public blog pages
4. **Reports** — date-range filtered, exportable reports (deeper than the Dashboard's at-a-glance charts)
5. **Payment Settings** — manage Razorpay key from the UI instead of editing `razorpay-config.js` by hand
6. **Shipping Settings** — shipping zones/rates, replacing the flat-rate assumption currently baked into checkout
7. **User Roles** — multiple admin accounts with different permission levels (currently: any signed-in user is a full admin)
8. **Website Settings** — site-wide settings (contact info, social links, announcement bar) editable from the UI
9. **Security panel** — surface the Firestore/Storage rules status, login activity, etc. inside the admin UI itself

**Also worth knowing:** the checkout page on the homepage doesn't yet have a coupon-code input field — the Coupons admin module is ready and the Firestore rules support a safe public lookup, but wiring the actual "Apply Coupon" box into the checkout modal is frontend work I'd bundle into Phase 2 alongside Shipping Settings (since discount + shipping logic usually get built together).

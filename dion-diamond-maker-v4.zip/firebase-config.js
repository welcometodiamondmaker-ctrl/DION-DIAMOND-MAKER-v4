// ============================================================
// DION DIAMOND MAKER — Shared Firebase Configuration
// ============================================================
// Single source of truth for Firebase project settings.
// Loaded by BOTH index.html and admin.html — edit values here
// only, no more copy-pasting the config object into every file.
//
// IMPORTANT (script order): this file just defines a plain object.
// It does NOT need the Firebase SDK to already be loaded, but
// everything that USES `firebaseConfig` (i.e. the Firebase SDK
// <script> tags + your own init code) must load AFTER this file
// and the SDK <script> tags must load before any code calls
// `firebase.initializeApp(...)`.
//
// Correct order in <head>/<body>, top to bottom:
//   1. firebase-app-compat.js
//   2. firebase-auth-compat.js
//   3. firebase-firestore-compat.js
//   4. firebase-storage-compat.js
//   5. (optional) firebase-analytics-compat.js
//   6. firebase-config.js   <-- this file
//   7. your own inline <script> that calls firebase.initializeApp(firebaseConfig)
// ============================================================

const firebaseConfig = {
  apiKey: "AIzaSyD1PH0_jYi_-1R5voQl3QZ8JN7ZG9TvZwY",
  authDomain: "diamond-maker-7be3e.firebaseapp.com",
  projectId: "diamond-maker-7be3e",
  storageBucket: "diamond-maker-7be3e.firebasestorage.app",
  messagingSenderId: "1060416753132",
  appId: "1:1060416753132:web:4b7854b3804aa8522844c9",
  measurementId: "G-0HKVBKW146"
};
